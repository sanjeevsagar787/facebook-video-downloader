from django.apps import AppConfig


class FbloaderConfig(AppConfig):
    name = 'fbloader'
