from django.shortcuts import render, redirect
import os
import fbdown #facebookdownload


def fbvidhome(request):
    if request.method == 'POST':
        try:    
            url = request.POST.get('url')
            homedir = os.path.expanduser("~")
            dirs = homedir + '/Downloads'
            d = fbdown.getdownlink(url)
            print(f'DIRECT :', f'{dirs}/Downloads')
            return redirect(d)
        except:
            return render(request, 'sorry.html')
    else:
        return render(request, 'fbhome.html')
#to download video
# fbdown.download('', 'D:\\')
#a = fbdown.get(url)

